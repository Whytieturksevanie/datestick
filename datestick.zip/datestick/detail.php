<?php

require 'header.php';
$id = $_GET['id'];
$sql = "SELECT * FROM user WHERE id = :id";
$prepare = $db->prepare($sql);
$prepare->execute([
    ':id' => $id
]);

$result = $prepare->fetch(PDO::FETCH_ASSOC);

?>
    
    <h1> De detail van deze persoon.</h1>

    <p class="namep">Naam: <?php echo $result['name']; ?></p>
    <p class="datep">De datum: <?php echo $result['date']; ?> </p>
    <p class="statusp">De status: <?php echo $result['status']; ?></p>

<?php

require 'footer.php';

?>