<?php require 'header.php'; ?>

    <h1> De datumprikker </h1>

    <main>
        <h2 class="dates">De datum's</h2>

            <?php
                echo "<h3>Beschikbaar</h3>";
                echo "<ul>";

            class ListRows extends RecursiveIteratorIterator {
                    function __construct($it) {
                    parent::__construct($it, self::LEAVES_ONLY);
                }

                function current() {
                    return "<li>" .parent::current(). "</li>";
                }

                function beginChildren() {
                    echo "<li>";
                }

                function endChildren() {
                    echo "</li>" . "\n";
                }
            }

                try {
                    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
                    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                    $stmt = $conn->prepare("SELECT available FROM availabilty");
                    $stmt->execute();

                  $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);
                  foreach(new ListRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) {
                    echo $v;
                  }
                } 
                
                catch(PDOException $e) {
                  echo "Error: " . $e->getMessage();
                }
                $conn = null;
                    echo "</ul>";
                ?>

                <?php
                    echo "<h3>Misschien beschikbaar</h3>";
                    echo "<ul>";

                class MaybeListRows extends RecursiveIteratorIterator {
                        function __construct($it) {
                        parent::__construct($it, self::LEAVES_ONLY);
                    }

                    function current() {
                        return "<li>" .parent::current(). "</li>";
                    }

                    function beginChildren() {
                        echo "<li>";
                    }

                    function endChildren() {
                        echo "</li>" . "\n";
                    }
                }

                try {
                    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
                    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                    $stmt = $conn->prepare("SELECT maybe_available FROM availabilty");
                    $stmt->execute();

                  $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);
                  foreach(new MaybeListRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) {
                    echo $v;
                  }
                } 
                
                catch(PDOException $e) {
                  echo "Error: " . $e->getMessage();
                }
                $conn = null;
                    echo "</ul>";
                ?>

                <?php
                    echo "<h3>Onbeschikbaar</h3>";
                    echo "<ul>";

                class UnavailableListRows extends RecursiveIteratorIterator {
                        function __construct($it) {
                        parent::__construct($it, self::LEAVES_ONLY);
                    }

                    function current() {
                        return "<li>" .parent::current(). "</li>";
                    }

                    function beginChildren() {
                        echo "<li>";
                    }

                    function endChildren() {
                        echo "</li>" . "\n";
                    }
                }

                try {
                    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
                    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                    $stmt = $conn->prepare("SELECT unavailable FROM availabilty");
                    $stmt->execute();

                  $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);
                  foreach(new UnavailableListRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) {
                    echo $v;
                  }
                } 
                
                catch(PDOException $e) {
                  echo "Error: " . $e->getMessage();
                }
                $conn = null;
                    echo "</ul>";
                ?>
                
                </main>

                <a class="datepage" href="datestick.php">De datumprikker</a>

                <?php require 'footer.php'; ?>

