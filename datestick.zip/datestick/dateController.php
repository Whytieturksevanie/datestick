<?php

if ($_SERVER ['REQUEST_METHOD'] != 'POST')
{
    header('location: datestick.php');
    exit;
}

require 'config.php';

if(empty($_POST['name'])){

    echo 'De naamveld is leeg';
    exit;
}


if(empty($_POST['date'])){

    echo 'De dateveld is leeg';
    exit;
}


if(empty($_POST['status'])){

    echo 'De statusveld is leeg';
    exit;
}

if ($_POST['type'] == 'create') {

    $name = $_POST['name'];
    $date = $_POST['date'];
    $status = $_POST['status'];

    $sql = "INSERT INTO user (name, date, status) VALUES (:name, :date, :status)";

    $prepare = $db->prepare($sql);
    $prepare->execute([
        ':name' => $name,
        ':date' => $date,
        ':status' => $status,
    ]);

    $msg = "De datum is succesvol aangemaakt!";
    header("location: datestick.php?msg=$msg");
    exit;
}

?>