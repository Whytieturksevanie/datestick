<?php
    require 'header.php';   
    $sql = "SELECT * FROM user";
    $query = $db->query($sql);
    $results = $query->fetchAll(PDO::FETCH_ASSOC);

?>

<?php

    if ( isset ( $_GET['msg'] ) )
    {
        echo "<p> {$_GET['msg']} </p>";
    }

?>

    <main class="datestickmain">

        <h2>Namen</h2>

        <ul>
            <?php
                foreach ($results as $result) {
                    $name = htmlentities($result ['name']);
                    echo "<li class=detailli><a href='detail.php?id={$result ['name']}'> $name </a> </li>";
                }
            ?>
        </ul>
    </main>
    
    <a class="createlink" href="create.php">Een nieuwe datum prikken</a>