
<?php

require 'header.php';
$sql = "SELECT available, maybe_available, unavailable FROM availabilty";
$prepare = $db->query($sql);
$results = $prepare->fetchAll(PDO::FETCH_ASSOC);

?>


    <h1>Hier kan u de datum inprikken</h1>

    <form action="dateController.php" method="post">
        <input type="hidden" name="type" value="create">
        <div class="form-group">
            <label class="namelabel" for="name">Naam</label>
        </div>
        <div>
            <input class="nameinput" type="text" name="name">
        </div>

        <div class="form-group">
            <label class="datelabel" for="date">De datum</label>
        </div>
        <div>
            <select class="statusselect" name="status" id="status">
                <option class="availableoption" value="<?php foreach ($results as $result) { echo $result["available"]; } ?>"><?php foreach ($results as $result) { echo $result["available"]; } ?></option>
                <option class="maybeavailableoption" value="<?php foreach ($results as $result) { echo $result["maybe_available"]; } ?>"><?php foreach ($results as $result) { echo $result["maybe_available"]; } ?></option>
                <option class="unavailableoption" value="<?php foreach ($results as $result) { echo $result["unavailable"]; } ?>"><?php foreach ($results as $result) { echo $result["unavailable"]; } ?></option>
            </select>
        </div>

        <div class="form-group">
            <label class="statuslabel" for="status">De status</label>
        </div>
        <div>
            <select class="statusselect" name="status" id="status">
                <option value="Ik kan">Ik kan</option>
                <option value="Ik kan misschien">Ik kan misschien</option>
                <option value="Ik kan niet">Ik kan niet</option>
            </select>
        </div>

        <div class="form-group">
            <input type="submit" value="Prikt een nieuw date in.">
        </div>
    </form>