<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Datestick</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <link href="{{ asset('css/custom.css') }}" rel="stylesheet">

</head>
<body>

    <h1>Hier kan u de datum inprikken</h1>

    <form action="{{ route('people.store') }}" method="post" enctype="multipart/form-data">
        @csrf
        <input type="hidden" name="type" value="create">
        <div class="form-group">
            <label class="namelabel" for="name">Naam</label>
        </div>
        <div>
            <input class="nameinput" type="text" name="name">
        </div>

        <div class="form-group">
            <label class="datelabel" for="date">De datum</label>
        </div>
        <div>
            <select class="statusselect" name="status" id="status">
            @foreach(\App\Date::select('available', 'maybe_available', 'unavailable', 'id')->get() as $date)
                <option value="{{ $date->id }}"> {{ $date->available }} </option> 
                <option value="{{ $date->id }}"> {{ $date->maybe_available }} </option> 
                <option value="{{ $date->id }}"> {{ $date->unavailable }} </option>
            @endforeach
            </select>
        </div>

        <div class="form-group">
            <label class="statuslabel" for="status">De status</label>
        </div>
        <div>
            <select class="statusselect" name="status" id="status">
                <option value="Ik kan">Ik kan</option>
                <option value="Ik kan misschien">Ik kan misschien</option>
                <option value="Ik kan niet">Ik kan niet</option>
            </select>
        </div>

        <div class="form-group">
            <input type="submit" value="Prikt een nieuw date in.">
        </div>
    </form>

</body>
</html>
