<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="stylesheet" href="{{asset('css/app.css')}}">
    <link rel="stylesheet" href="{{asset('css/custom.css')}}">
    <script src="{{ asset('js/app.js') }}" defer></script>

    <title>Datestick</title>
    <!-- Scripts -->
{{--<script src="{{ asset('js/app.js') }}" defer></script>--}}
<!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

</head>
<body>

<header>
    <div>
        <h1 class="maintenance">De namen</h1>

        <ul class="theleaselist">
            @foreach(\App\People::select('name', 'id')->get() as $people)
                <li><a href="{{ route('people.show', $people->id ) }}"> {{$people->name}}</a> </li>
            @endforeach 
        </ul>
    </div>
</header>

<a href="{{route('people.create')}}"create.php">Een nieuwe datum prikken</a>

</body>
</html>