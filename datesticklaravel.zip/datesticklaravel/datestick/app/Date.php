<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Date extends Model
{
    public $table = "availabilty";

    protected $fillable = ['available', 'maybe_available', 'unavailable'];
}
