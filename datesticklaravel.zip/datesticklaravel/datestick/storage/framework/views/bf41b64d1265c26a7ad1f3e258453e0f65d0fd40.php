<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>datestick</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet">

</head>
<body>

    <h1>Hier kan u de datum inprikken</h1>

    <form action="<?php echo e(route('people.store')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="type" value="create">
        <div class="form-group">
            <label class="namelabel" for="name">Naam</label>
        </div>
        <div>
            <input class="nameinput" type="text" name="name">
        </div>

        <div class="form-group">
            <label class="datelabel" for="date">De datum</label>
        </div>
        <div>
            <select class="statusselect" name="status" id="status">
            <?php $__currentLoopData = \App\Date::select('available', 'maybe_available', 'unavailable', 'id')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($date->id); ?>"> <?php echo e($date->available); ?> </option> 
                <option value="<?php echo e($date->id); ?>"> <?php echo e($date->maybe_available); ?> </option> 
                <option value="<?php echo e($date->id); ?>"> <?php echo e($date->unavailable); ?> </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="form-group">
            <label class="statuslabel" for="status">De status</label>
        </div>
        <div>
            <select class="statusselect" name="status" id="status">
                <option value="Ik kan">Ik kan</option>
                <option value="Ik kan misschien">Ik kan misschien</option>
                <option value="Ik kan niet">Ik kan niet</option>
            </select>
        </div>

        <div class="form-group">
            <input type="submit" value="Prikt een nieuw date in.">
        </div>
    </form>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\datesticklaravel\datestick\resources\views/people/create.blade.php ENDPATH**/ ?>