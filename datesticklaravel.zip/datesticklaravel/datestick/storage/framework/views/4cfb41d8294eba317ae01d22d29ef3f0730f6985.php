<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <title>Barroc Intense</title>
    <!-- Scripts -->

<!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

</head>
<body>

<header>
    <div>
        <h1 class="maintenance">De namen</h1>

        <ul class="theleaselist">
            <?php $__currentLoopData = \App\People::select('name', 'id')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $people): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="<?php echo e(route('people.show', $people->id)); ?>"> <?php echo e($people->name); ?></a> </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        </ul>
    </div>
</header>

<a href="<?php echo e(route('people.create')); ?>"create.php">Een nieuwe datum prikken</a>

</body>
</html><?php /**PATH C:\xampp\htdocs\datesticklaravel\datestick\resources\views/datestick.blade.php ENDPATH**/ ?>