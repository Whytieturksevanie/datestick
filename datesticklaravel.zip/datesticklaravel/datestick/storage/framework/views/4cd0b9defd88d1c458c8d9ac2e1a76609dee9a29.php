<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <title>Datestick</title>
    </head>
<body>

    <header>
        <h1> De datumprikker </h1>
    </header>

    <main>
        <h2 class="dates">De datum's</h2>
        <ul class="availbledate">
            <?php $__currentLoopData = \App\Date::select('available', 'maybe_available', 'unavailable')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($date->available); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

        <ul class="maybeavailbledate" >
            <?php $__currentLoopData = \App\Date::select('available', 'maybe_available', 'unavailable')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($date->maybe_available); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

        <ul class="unavailbledate">
            <?php $__currentLoopData = \App\Date::select('available', 'maybe_available', 'unavailable')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($date->available); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </main>
    
    <footer>
        <a class="datepage" href="<?php echo e(route('people.index')); ?>">De datumprikker</a>     
    </footer>

</body>
</html>

<?php /**PATH C:\xampp\htdocs\datesticklaravel\datestick\resources\views/welcome.blade.php ENDPATH**/ ?>