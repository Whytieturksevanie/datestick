
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <title>Barroc Intense</title>
    <!-- Scripts -->

<!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

</head>
<body>
<h1 class="headtextlease">De persoongegevens</h1>

<p class="leaseslabelcustomer"> Id: <?php echo e($people->id); ?></p>
<p class="leaseinfocustomer"> Naam: <?php echo e($people->name); ?></p>
<p class="leaseinfocustomer"> De datum: <?php echo e($people->date); ?></p>
<p class="leaseinfocustomer"> De status: <?php echo e($people->status); ?></p>

</body>
</html>

<?php /**PATH C:\xampp\htdocs\datesticklaravel\datestick\resources\views/people/show.blade.php ENDPATH**/ ?>